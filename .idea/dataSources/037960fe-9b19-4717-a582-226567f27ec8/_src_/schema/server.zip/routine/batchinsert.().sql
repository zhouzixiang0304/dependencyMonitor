CREATE PROCEDURE `batchinsert`()
  BEGIN
    DECLARE i INT;
    SET i=1;
    WHILE i < 1001 DO
      INSERT INTO serverconnection VALUES (
        concat("class",cast(i*3%1000 AS CHAR)),
        concat("func",cast(i%7 AS CHAR)),
        concat("class",cast(i*7%1000 AS CHAR)),
        concat("func",cast(i*3%7 AS CHAR)),
        concat("test",cast(i AS CHAR))
      );
      SET i = i + 1;
    END WHILE;
  END